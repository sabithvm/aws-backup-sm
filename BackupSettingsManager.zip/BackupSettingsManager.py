# pylint: disable = C0103, R0902, W1203, C0301, W0311
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

This file contains the code for the Lambda function that handles custom
cloudformation resource management for Organization policies
"""

import time
import json
import urllib3
import os
import sys
from pip._internal import main

# install latest version of boto3
main(['install', '-I', '-q', 'boto3', '--target', '/tmp/', '--no-cache-dir', '--disable-pip-version-check'])
sys.path.insert(0,'/tmp/')
import boto3

BACKUP_ALL_SETTINGS_TYPE = 'All'


def get_region_list():
  # List all regions
  client = boto3.client('ec2')
  region_list = [region['RegionName'] for region in client.describe_regions()['Regions']]
  return region_list
  
def get_supported_resource_types_list():
  # List all regions
  client = boto3.client('backup')
  supported_resource_types = client.get_supported_resource_types()['ResourceTypes']
  return supported_resource_types

def lambda_handler(event, context):
      """
      Main Lambda handler function. This function will handle the Create, Update and Delete operation requests
      from CloudFormation
      """
      try:
        #create physical resource id
        physical_resource_id = 'BackupCustomResourceManager'
        status = 'SUCCESS'

        if 'PhysicalResourceId' in event:
          physical_resource_id = event['PhysicalResourceId']

        print(f"BackupCustomResourceManager Request: {event}")
        resource_action = event['RequestType']
        affected_regions = event['ResourceProperties']['AffectedRegions'].strip()
        affected_resource_types = event['ResourceProperties']['ResourceTypeOptIn'].strip()
        resource_type_management = event['ResourceProperties']['ResourceTypeManagement'].strip()
        service_action = event['ResourceProperties']['ServiceAction'].strip().lower()
        
        preference_type = False
        if service_action == 'enable':
          preference_type = True
        
        affected_region_list = affected_regions.split(',')
        if BACKUP_ALL_SETTINGS_TYPE in affected_regions:
          affected_region_list = get_region_list()
          
        if resource_action == 'Create' or resource_action == 'Update':
          for affected_region in affected_region_list:
              try:
                  print(f'Processing update for region : {affected_region}')
                  supported_resource_types_list = get_supported_resource_types_list()  
                  affected_resource_types_list = []
                  if affected_resource_types:
                    affected_resource_types_list = affected_resource_types.split(',')
                    
                  if BACKUP_ALL_SETTINGS_TYPE in affected_resource_types_list:
                    affected_resource_types_list = supported_resource_types_list
                    
                  resource_type_management_list = []
                  if resource_type_management:
                    resource_type_management_list = resource_type_management.split(',') 
                    
                  if BACKUP_ALL_SETTINGS_TYPE in resource_type_management_list:
                    resource_type_management_list = ['DynamoDB']
                    
                  backup_client = boto3.client('backup',affected_region)
                  region_settings_response = backup_client.describe_region_settings()
                  print(f'region_settings_response : {region_settings_response}')
                  
                  resource_type_opt_in_preference_dict = region_settings_response['ResourceTypeOptInPreference']
                  resource_type_management_preference_dict = region_settings_response['ResourceTypeManagementPreference']
                  
                  for affected_resource_type in affected_resource_types_list:
                      print(f'Setting resource_type_opt_in_preference for {affected_resource_type} as {preference_type}')
                      resource_type_opt_in_preference_dict[affected_resource_type] = preference_type
    
                  if len(resource_type_management_list) > 0:
                    for resource_type_management_preference in resource_type_management_list:
                        print(f'Setting resource_type_management_preference for {resource_type_management_preference} as {preference_type}')
                        resource_type_management_preference_dict[resource_type_management_preference] = preference_type
    
                  print(f'ResourceTypeOptInPreference={resource_type_opt_in_preference_dict},ResourceTypeManagementPreference={resource_type_management_preference_dict}')
                  response = backup_client.update_region_settings(ResourceTypeOptInPreference=resource_type_opt_in_preference_dict,
                                                           ResourceTypeManagementPreference=resource_type_management_preference_dict)
                                                           
                  print(f'update_region_settings response :{response}')  
                  
              except Exception as exc:
                print(f"Exception processing update for region :{affected_region} as : {str(exc)}")                  
              
          response_data = {
                'AffectedRegions': affected_regions,
                'ResourceTypeOptIn': affected_resource_types,
                'ServiceAction': service_action,
                'Message': 'Custom Resources Created successfully'
          }
        elif resource_action == 'Delete':
          response_data = {
                'AffectedRegions': affected_regions,
                'ResourceTypeOptIn': affected_resource_types,
                'ServiceAction': service_action,
                'Message': 'Delete Operation NOT Supported'
          }
        else:
          print(f"ERROR.Unexpected Action : {resource_action}")
          response_data = {
                          'Message': 'Unexpected event received from CloudFormation'
          }
          status = 'FAILED'
      except Exception as exc:
        print(f"Exception: {str(exc)}")
        response_data = {
                      'Message': str(exc)
        }
        status = 'FAILED'

      #Send the response for the CFN Stack operation request
      send(event, context, status, response_data, physical_resource_id)


def send(event, context, response_status, response_data, physical_resource_id, no_echo=False):  # pylint: disable = R0913
      """
      Helper function for sending updates on the custom resource to CloudFormation during a
      'Create', 'Update', or 'Delete' event.
      """

      http = urllib3.PoolManager()
      response_url = event['ResponseURL']

      json_response_body = json.dumps({
          'Status': response_status,
          'Reason': response_data['Message'] + f', See the details in CloudWatch Log Stream: {context.log_stream_name}',
          'PhysicalResourceId': physical_resource_id,
          'StackId': event['StackId'],
          'RequestId': event['RequestId'],
          'LogicalResourceId': event['LogicalResourceId'],
          'NoEcho': no_echo,
          'Data': response_data
      }).encode('utf-8')

      headers = {
          'content-type': '',
          'content-length': str(len(json_response_body))
      }

      try:
          http.request('PUT', response_url,
                        body=json_response_body, headers=headers)
      except Exception as e:  # pylint: disable = W0703
          print(e)